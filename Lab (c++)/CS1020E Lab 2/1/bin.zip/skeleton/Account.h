#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

using namespace std;

class Account {
	private:
	// data member goes here
	// account name
		
	// initial balance
		
	// current balance
		
	public:
	// constructors, destructors
		
	// setters, getters
};

#endif
