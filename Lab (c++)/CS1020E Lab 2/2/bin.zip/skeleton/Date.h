/**********************
 *
 * Name:
 * Matric No:
 * Plab Account:
 *
 **********************/

#ifndef DATE_H
#define DATE_H

#include <string>
using namespace std;

class Date
{
    private:
        int day;
        int month;
        int year;
    public:
        // Constructors

        // Setters and getters

        // Precondition:
        // Postcondition:
        int compare(Date date);
};

#endif
