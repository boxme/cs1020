/**********************
 *
 * Name:
 * Matric No:
 * Plab Account:
 *
 **********************/

#ifndef BUILDING_H
#define BUILDING_H

#include <string>
#include "Date.h"
using namespace std;

class Building
{
    private:
        string building_name;
        string location;
        Date opening_date;
    public:
        // Constructors

        // Setters and getters
};

#endif
