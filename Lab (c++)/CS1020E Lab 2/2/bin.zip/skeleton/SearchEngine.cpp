#include "SearchEngine.h"
#include <iostream>
using namespace std;

bool SearchEngine::addBuilding(string building_name, string location, Date
        opening_date)
{
    // your code here
}

vector<Building> SearchEngine::search(string keyword)
{
    // your code here
}

Building SearchEngine::findOldestBuilding()
{
    // your code here
}

Building SearchEngine::findNewestBuilding()
{
    // your code here
}

int main() {
    // create a search engine object

    // read and process input

    return 0;
}
