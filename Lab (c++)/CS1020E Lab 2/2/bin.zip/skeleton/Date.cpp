#include "Date.h"

int Date::compare(Date date)
{
    // your code here
}
